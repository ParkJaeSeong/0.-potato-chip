import roboter.controller.conversation
roboter.controller.conversation.talk_about_restaurant()
